# ClassPulse - smart school attendance (prototype)

A simulated school morning with ~230 students, 8 classes, card readers, optional
face check-in, live dashboards and parent SMS alerts. Self-contained: no
backend or hardware needed.

## Run (inside your CropMedic folder)
    flutter create classpulse
    cd classpulse
Copy pubspec.yaml and lib/ from this folder into it (replace the originals), then:
    flutter pub get
    flutter run -d chrome

## What you will see
- PULSE: live "in school" ring, arrivals chart with the bell line, live check-in
  feed, parents texted, at-risk students. The school day runs in about 3 minutes.
- CLASSES: a tile per classroom. Tap one for its register; mark a student present
  or excused.
- SCAN: a check-in station for CARD, FACE or QR with live animations.
- INSIGHTS: plain-language alerts (shared cards, late clusters like a bus delay,
  high absence, dropout risk) and the privacy settings.

## Demo menu (flask icon)
Skip to 08:30 (register closes: absent students are texted to guardians), shared
card alert, unknown card alert, restart. Use the pause button to stop the clock.

## Privacy by design
- Cards are the default. Face check-in is OFF unless switched on, and only works
  for students whose guardians consented.
- No face photos are stored (encrypted templates on the device only).
- Check legal requirements (for example Zimbabwe's Cyber and Data Protection Act,
  and rules about children's data) before using with real students.

## Going from prototype to real
All data comes from lib/sim.dart (class SchoolSim). Replace it with a class that
has the same fields, filled from your RFID readers via a school gateway that works
offline and syncs later. The screens do not need to change.
