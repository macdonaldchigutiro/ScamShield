import 'package:flutter/material.dart';

import 'pulse_screen.dart';
import 'sim.dart';
import 'theme.dart';

class ClassesScreen extends StatelessWidget {
  final SchoolSim sim;
  const ClassesScreen({super.key, required this.sim});

  Color _color(ClassRoom c) {
    final pct = c.students.isEmpty ? 0.0 : c.here / c.students.length;
    if (!sim.cutoffDone) return pct > 0.85 ? Palette.lime : Palette.cyan;
    if (pct >= 0.9) return Palette.lime;
    if (pct >= 0.75) return Palette.amber;
    return Palette.red;
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
      children: [
        const Text('CLASSROOMS  (TAP ONE FOR THE REGISTER)',
            style: TextStyle(color: Palette.cyan, letterSpacing: 2, fontSize: 11)),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.45,
          children: [
            for (final c in sim.classes)
              GestureDetector(
                onTap: () => _openRegister(context, c),
                child: GlassCard(
                  borderColor: _color(c).withOpacity(0.5),
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            CustomPaint(
                              size: const Size(60, 60),
                              painter: RingPainter(
                                  c.students.isEmpty ? 0 : c.here / c.students.length,
                                  _color(c),
                                  thickness: 6),
                            ),
                            Text(
                              '${c.students.isEmpty ? 0 : (c.here * 100 / c.students.length).round()}%',
                              style: TextStyle(
                                  color: _color(c),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(c.id,
                                style: const TextStyle(
                                    color: Palette.text,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 15)),
                            Text('${c.here}/${c.students.length} here',
                                style: const TextStyle(
                                    color: Palette.dim, fontSize: 11)),
                            Text(
                              '${c.count(Status.late)} late • ${c.count(Status.absent)} absent',
                              style: const TextStyle(
                                  color: Palette.dim, fontSize: 10),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }

  void _openRegister(BuildContext context, ClassRoom c) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.85,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, controller) => AnimatedBuilder(
          animation: sim,
          builder: (context, _) {
            final list = [...c.students]
              ..sort((a, b) => a.status.index.compareTo(b.status.index));
            return Container(
              decoration: const BoxDecoration(
                color: Color(0xFF0E0B2A),
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                border: Border(top: BorderSide(color: Palette.glassBorder)),
              ),
              child: ListView(
                controller: controller,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Palette.glassBorder,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text('${c.id} REGISTER',
                      style: const TextStyle(
                          color: Palette.cyan, letterSpacing: 3, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(
                    '${c.here} here • ${c.count(Status.late)} late • ${c.count(Status.absent)} absent • ${c.count(Status.pending)} not yet',
                    style: const TextStyle(color: Palette.dim, fontSize: 12),
                  ),
                  const SizedBox(height: 12),
                  for (final s in list)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: GlassCard(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        child: Row(
                          children: [
                            Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: statusColor(s.status),
                                boxShadow: [
                                  BoxShadow(
                                      color: statusColor(s.status).withOpacity(0.7),
                                      blurRadius: 6)
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(s.name,
                                      style: const TextStyle(
                                          color: Palette.text,
                                          fontWeight: FontWeight.w600)),
                                  Text(
                                    s.tappedAt == null
                                        ? statusLabel(s.status)
                                        : '${statusLabel(s.status)} • ${fmt(s.tappedAt!)} • ${methodLabel(s.method ?? Method.rfid)}',
                                    style: TextStyle(
                                        color: statusColor(s.status),
                                        fontSize: 10,
                                        letterSpacing: 1),
                                  ),
                                ],
                              ),
                            ),
                            PopupMenuButton<String>(
                              icon: const Icon(Icons.more_vert,
                                  color: Palette.dim, size: 20),
                              color: const Color(0xFF1A1545),
                              onSelected: (v) {
                                if (v == 'present') sim.markPresent(s);
                                if (v == 'excused') sim.markExcused(s);
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(
                                    value: 'present',
                                    child: Text('Mark present')),
                                PopupMenuItem(
                                    value: 'excused',
                                    child: Text('Mark excused')),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
