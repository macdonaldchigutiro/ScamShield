import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';

enum Status { pending, present, late, absent, excused }

enum Method { rfid, face, qr, manual }

class Student {
  final String id, name, classId;
  final bool consentFace;
  final int absentStreak;
  Status status = Status.pending;
  Method? method;
  double? arriveAt;
  double? tappedAt;
  Student(this.id, this.name, this.classId, this.consentFace, this.absentStreak);
}

class ClassRoom {
  final String id;
  final List<Student> students;
  ClassRoom(this.id, this.students);

  int count(Status s) => students.where((x) => x.status == s).length;
  int get here => count(Status.present) + count(Status.late);
}

class TapEvent {
  final Student student;
  final double minute;
  final Method method;
  final String gate;
  final Status status;
  TapEvent(this.student, this.minute, this.method, this.gate, this.status);
}

class SchoolAlert {
  final String id, title, detail, severity, kind; // critical, warning, info
  const SchoolAlert(this.id, this.title, this.detail, this.severity, this.kind);
}

class TapResult {
  final Student? student;
  final String message;
  final bool ok;
  final bool duplicate;
  TapResult(this.student, this.message, this.ok, {this.duplicate = false});
}

const _firsts = [
  'Tendai', 'Rudo', 'Farai', 'Chipo', 'Tatenda', 'Nyasha', 'Kudzai', 'Tariro',
  'Blessing', 'Tafara', 'Anesu', 'Ruvimbo', 'Takudzwa', 'Simba', 'Panashe',
  'Shamiso', 'Tino', 'Vimbai', 'Munashe', 'Rutendo', 'Thabo', 'Nomsa', 'Sipho',
  'Lindiwe', 'Themba', 'Zodwa', 'Bongani', 'Nokuthula', 'Mthabisi', 'Precious',
];
const _lasts = [
  'Moyo', 'Ncube', 'Dube', 'Sibanda', 'Mutasa', 'Makoni', 'Chirwa', 'Ndlovu',
  'Mpofu', 'Banda', 'Gumbo', 'Marufu', 'Zhou', 'Mhlanga', 'Phiri', 'Tshuma',
  'Nyoni', 'Masuku', 'Chikwanha', 'Mandaza',
];
const _classIds = [
  'Form 1A', 'Form 1B', 'Form 2A', 'Form 2B', 'Form 3A', 'Form 3B', 'Form 4A',
  'Form 4B',
];
const _gates = ['Main Gate', 'North Gate', 'Back Gate'];

/// A simulated school morning. Swap this class for real reader data later.
class SchoolSim extends ChangeNotifier {
  static const dayStart = 390.0; // 06:30
  static const bell = 465.0; // 07:45
  static const cutoff = 510.0; // 08:30 register closes
  static const dayEnd = 600.0; // 10:00
  static const step = 0.4;

  final math.Random _rnd = math.Random(42);
  double minutes = dayStart;
  bool running = true;
  bool faceEnabled = false;
  bool cutoffDone = false;
  int guardiansNotified = 0;
  int _aid = 0;
  final List<ClassRoom> classes = [];
  final List<TapEvent> events = [];
  final List<SchoolAlert> anomalies = [];
  final List<int> buckets = List.filled(36, 0);
  Timer? _timer;

  SchoolSim() {
    _init();
    _timer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      if (!running) return;
      _advance();
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  double _gauss() {
    final u1 = math.max(1e-9, _rnd.nextDouble());
    final u2 = _rnd.nextDouble();
    return math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2);
  }

  void _init() {
    minutes = dayStart;
    cutoffDone = false;
    guardiansNotified = 0;
    events.clear();
    anomalies.clear();
    classes.clear();
    for (int i = 0; i < buckets.length; i++) {
      buckets[i] = 0;
    }
    int n = 0;
    for (final cid in _classIds) {
      final count = 26 + _rnd.nextInt(7);
      final list = <Student>[];
      for (int i = 0; i < count; i++) {
        n++;
        final name =
            '${_firsts[_rnd.nextInt(_firsts.length)]} ${_lasts[_rnd.nextInt(_lasts.length)]}';
        final r = _rnd.nextDouble();
        final streak = r < 0.85 ? 0 : (r < 0.95 ? 1 + _rnd.nextInt(2) : 3 + _rnd.nextInt(3));
        final s = Student('s$n', name, cid, _rnd.nextDouble() < 0.45, streak);
        final away = _rnd.nextDouble() < (streak >= 3 ? 0.55 : 0.05);
        if (away) {
          s.arriveAt = null;
        } else {
          double a = 450 + _gauss() * 17;
          if (cid == 'Form 2B' && _rnd.nextDouble() < 0.5) a += 22;
          s.arriveAt = a.clamp(405.0, 560.0).toDouble();
        }
        list.add(s);
      }
      classes.add(ClassRoom(cid, list));
    }
  }

  // ----- reading the school -----

  List<Student> get all => [for (final c in classes) ...c.students];
  int get total => all.length;
  int _c(Status s) => all.where((x) => x.status == s).length;
  int get presentCount => _c(Status.present);
  int get lateCount => _c(Status.late);
  int get here => presentCount + lateCount;
  int get absentCount => _c(Status.absent);
  int get excusedCount => _c(Status.excused);
  int get pendingCount => _c(Status.pending);
  double get herePct => total == 0 ? 0 : here / total;
  double get absentPct => total == 0 ? 0 : absentCount / total;
  List<Student> get atRisk =>
      all.where((s) => s.status == Status.absent && s.absentStreak >= 2).toList();

  String get phase {
    if (minutes < bell) return 'Before the bell';
    if (minutes < cutoff) return 'Late period';
    return 'Register closed';
  }

  List<SchoolAlert> get alerts {
    final a = <SchoolAlert>[...anomalies];
    for (final c in classes) {
      final late = c.count(Status.late);
      if (late >= 6) {
        a.add(SchoolAlert(
          'late-${c.id}',
          'Many late arrivals in ${c.id}',
          '$late students arrived after the bell. This is often a transport problem, so check for bus or road delays.',
          'warning',
          'late',
        ));
      }
    }
    if (cutoffDone) {
      final risk = atRisk;
      if (risk.isNotEmpty) {
        a.add(SchoolAlert(
          'risk',
          '${risk.length} students at risk of dropping out',
          'Absent today after being away several days in a row, for example ${risk.take(3).map((s) => s.name).join(', ')}. A call or home visit can help.',
          'warning',
          'risk',
        ));
      }
      if (absentPct > 0.12) {
        a.add(SchoolAlert(
          'absence',
          'High absence today',
          '$absentCount of $total students are absent (${(absentPct * 100).round()}%). Check for a local event, illness or weather.',
          'warning',
          'absence',
        ));
      }
      a.add(SchoolAlert(
        'sms',
        'Guardians notified',
        '$guardiansNotified guardians were sent an SMS about their child\'s absence.',
        'info',
        'sms',
      ));
    }
    return a;
  }

  // ----- simulation -----

  Method _pickMethod(Student s) {
    if (faceEnabled && s.consentFace && _rnd.nextDouble() < 0.35) {
      return Method.face;
    }
    return _rnd.nextDouble() < 0.92 ? Method.rfid : Method.manual;
  }

  TapEvent _register(Student s, {Method? force}) {
    final m = force ?? _pickMethod(s);
    final gate = m == Method.manual ? 'Teacher tablet' : _gates[_rnd.nextInt(_gates.length)];
    s.status = minutes <= bell ? Status.present : Status.late;
    s.method = m;
    s.tappedAt = minutes;
    s.arriveAt = null;
    final e = TapEvent(s, minutes, m, gate, s.status);
    events.insert(0, e);
    if (events.length > 60) events.removeLast();
    final b = ((minutes - dayStart) / 5).floor();
    if (b >= 0 && b < buckets.length) buckets[b]++;
    return e;
  }

  void _advance() {
    minutes = math.min(minutes + step, dayEnd);
    for (final c in classes) {
      for (final s in c.students) {
        if (s.status == Status.pending &&
            s.arriveAt != null &&
            s.arriveAt! <= minutes) {
          _register(s);
        }
      }
    }
    if (minutes >= 430 && minutes <= 520) {
      if (anomalies.where((a) => a.kind == 'duplicate').length < 2 &&
          _rnd.nextDouble() < 0.012) {
        _addDuplicate();
      }
      if (anomalies.where((a) => a.kind == 'unknown').length < 2 &&
          _rnd.nextDouble() < 0.008) {
        _addUnknown();
      }
    }
    if (!cutoffDone && minutes >= cutoff) _cutoff();
  }

  void _cutoff() {
    cutoffDone = true;
    int n = 0;
    for (final s in all) {
      if (s.status == Status.pending) {
        s.status = Status.absent;
        n++;
      }
    }
    guardiansNotified = n;
  }

  void _addDuplicate() {
    final pool =
        all.where((s) => s.status == Status.present || s.status == Status.late).toList();
    if (pool.isEmpty) return;
    final s = pool[_rnd.nextInt(pool.length)];
    anomalies.add(SchoolAlert(
      'dup-${_aid++}',
      'Possible shared card',
      '${s.name} (${s.classId}) tapped at two gates within a minute. Another student may be using this card.',
      'warning',
      'duplicate',
    ));
  }

  void _addUnknown() {
    anomalies.add(SchoolAlert(
      'unk-${_aid++}',
      'Unregistered card tapped',
      'An unknown card was tapped at the ${_gates[_rnd.nextInt(_gates.length)]}. It may be a lost, new or borrowed card.',
      'info',
      'unknown',
    ));
  }

  // ----- actions -----

  void togglePlay() {
    running = !running;
    notifyListeners();
  }

  void setFace(bool v) {
    faceEnabled = v;
    notifyListeners();
  }

  void markPresent(Student s) {
    s.status = Status.present;
    s.method = Method.manual;
    s.tappedAt = minutes;
    notifyListeners();
  }

  void markExcused(Student s) {
    s.status = Status.excused;
    notifyListeners();
  }

  TapResult simulateTap(Method m) {
    if (m == Method.face && !faceEnabled) {
      return TapResult(null,
          'Face recognition is switched off. You can turn it on in Insights, under Privacy.', false);
    }
    final pending = all
        .where((s) =>
            s.status == Status.pending && (m != Method.face || s.consentFace))
        .toList();
    if (pending.isEmpty) {
      if (m == Method.face) {
        return TapResult(null, 'No students with guardian consent are waiting.', false);
      }
      final done = all
          .where((s) => s.status == Status.present || s.status == Status.late)
          .toList();
      if (done.isEmpty) return TapResult(null, 'Nobody to scan.', false);
      final s = done[_rnd.nextInt(done.length)];
      return TapResult(
        s,
        'Already registered at ${fmt(s.tappedAt ?? minutes)}. No double entry.',
        false,
        duplicate: true,
      );
    }
    final s = pending[_rnd.nextInt(pending.length)];
    _register(s, force: m);
    notifyListeners();
    return TapResult(
      s,
      s.status == Status.late ? 'Registered as late' : 'Registered on time',
      true,
    );
  }

  // ----- demo controls -----

  void skipToCutoff() {
    while (minutes < cutoff) {
      _advance();
    }
    notifyListeners();
  }

  void injectDuplicate() {
    _addDuplicate();
    notifyListeners();
  }

  void injectUnknown() {
    _addUnknown();
    notifyListeners();
  }

  void reset() {
    _init();
    running = true;
    notifyListeners();
  }
}
