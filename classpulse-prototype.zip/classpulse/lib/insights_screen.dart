import 'package:flutter/material.dart';

import 'sim.dart';
import 'theme.dart';

class InsightsScreen extends StatelessWidget {
  final SchoolSim sim;
  const InsightsScreen({super.key, required this.sim});

  Color _sev(String s) {
    switch (s) {
      case 'critical':
        return Palette.red;
      case 'warning':
        return Palette.amber;
      default:
        return Palette.cyan;
    }
  }

  IconData _icon(String kind) {
    switch (kind) {
      case 'duplicate':
        return Icons.content_copy;
      case 'unknown':
        return Icons.help_outline;
      case 'late':
        return Icons.directions_bus_outlined;
      case 'risk':
        return Icons.crisis_alert;
      case 'absence':
        return Icons.sick_outlined;
      default:
        return Icons.sms_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final alerts = sim.alerts;
    final consenting = sim.all.where((s) => s.consentFace).length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        const Text('INSIGHTS AND ALERTS',
            style: TextStyle(color: Palette.cyan, letterSpacing: 2, fontSize: 12)),
        const SizedBox(height: 4),
        const Text('Problems are explained in plain language, with a suggested next step.',
            style: TextStyle(color: Palette.dim, fontSize: 12)),
        const SizedBox(height: 12),
        if (alerts.isEmpty)
          const GlassCard(
            child: Row(
              children: [
                Icon(Icons.verified_user_rounded, color: Palette.lime, size: 30),
                SizedBox(width: 12),
                Expanded(
                  child: Text('Nothing needs your attention right now.',
                      style: TextStyle(color: Palette.text)),
                ),
              ],
            ),
          )
        else
          for (final a in alerts)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GlassCard(
                borderColor: _sev(a.severity).withOpacity(0.6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _sev(a.severity).withOpacity(0.15),
                      ),
                      child: Icon(_icon(a.kind), color: _sev(a.severity)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(a.title,
                              style: const TextStyle(
                                  color: Palette.text,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15)),
                          const SizedBox(height: 4),
                          Text(a.detail,
                              style: const TextStyle(
                                  color: Palette.dim, fontSize: 13, height: 1.4)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        const SizedBox(height: 14),
        const Text('PRIVACY AND TRUST',
            style: TextStyle(color: Palette.cyan, letterSpacing: 2, fontSize: 12)),
        const SizedBox(height: 10),
        GlassCard(
          borderColor: Palette.violet.withOpacity(0.5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.face_retouching_natural, color: Palette.violet),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text('Face recognition',
                        style: TextStyle(
                            color: Palette.text,
                            fontWeight: FontWeight.w700,
                            fontSize: 15)),
                  ),
                  Switch(
                    value: sim.faceEnabled,
                    activeColor: Palette.violet,
                    onChanged: (v) => sim.setFace(v),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                sim.faceEnabled
                    ? 'ON for students whose guardians gave consent ($consenting of ${sim.total}). Everyone else keeps using cards.'
                    : 'OFF. Everyone checks in with cards. Turn this on only after guardians have agreed.',
                style: const TextStyle(color: Palette.dim, fontSize: 13, height: 1.4),
              ),
              const Divider(color: Palette.glassBorder, height: 24),
              const _Row(Icons.no_photography_outlined, 'Face photos stored', 'None'),
              const _Row(Icons.lock_outline, 'Face data', 'Kept on the device as an encrypted template'),
              const _Row(Icons.rule, 'Guardian consent', 'Required for each student'),
              const _Row(Icons.history_toggle_off, 'Retention', 'Deleted when a student leaves'),
              const SizedBox(height: 8),
              const Text(
                'Designed around data-protection rules such as Zimbabwe\'s Cyber and Data Protection Act. Check the legal requirements before using it with real students.',
                style: TextStyle(color: Palette.dim, fontSize: 11, height: 1.4),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String label, value;
  const _Row(this.icon, this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: Palette.lime),
          const SizedBox(width: 10),
          Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                      text: '$label:  ',
                      style: const TextStyle(color: Palette.dim, fontSize: 13)),
                  TextSpan(
                      text: value,
                      style: const TextStyle(color: Palette.text, fontSize: 13)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
