import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

class Palette {
  static const bg = Color(0xFF070614);
  static const bgTop = Color(0xFF15103A);
  static const violet = Color(0xFF8B5CF6);
  static const cyan = Color(0xFF22D3EE);
  static const lime = Color(0xFF7CFF6B);
  static const amber = Color(0xFFFBBF24);
  static const red = Color(0xFFFF5470);
  static const text = Color(0xFFEEF0FF);
  static const dim = Color(0xFF9A97C0);
  static const glass = Color(0x12FFFFFF);
  static const glassBorder = Color(0x22FFFFFF);
}

const auroraGradient = LinearGradient(colors: [Palette.violet, Palette.cyan]);
const limeGradient = LinearGradient(colors: [Palette.lime, Palette.cyan]);

void drawText(Canvas canvas, String s, Offset center, double size, Color color,
    {FontWeight weight = FontWeight.w600, double letterSpacing = 0}) {
  final tp = TextPainter(
    text: TextSpan(
      text: s,
      style: TextStyle(
        color: color,
        fontSize: size,
        fontWeight: weight,
        letterSpacing: letterSpacing,
      ),
    ),
    textDirection: TextDirection.ltr,
  )..layout();
  tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
}

String fmt(double minutes) {
  final h = (minutes ~/ 60) % 24;
  final m = (minutes % 60).floor();
  return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}';
}

/// Dark background with three slowly drifting aurora glows.
class AuroraBackground extends StatefulWidget {
  final Widget child;
  const AuroraBackground({super.key, required this.child});

  @override
  State<AuroraBackground> createState() => _AuroraBackgroundState();
}

class _AuroraBackgroundState extends State<AuroraBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 16),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Widget _orb(Color c, double size) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [c.withOpacity(0.2), c.withOpacity(0.0)],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Palette.bgTop, Palette.bg],
        ),
      ),
      child: Stack(
        children: [
          AnimatedBuilder(
            animation: _c,
            builder: (context, _) => Stack(
              children: [
                Positioned(
                  top: -150 + 70 * _c.value,
                  left: -120 + 60 * _c.value,
                  child: _orb(Palette.violet, 360),
                ),
                Positioned(
                  top: 260 - 60 * _c.value,
                  right: -170 + 40 * _c.value,
                  child: _orb(Palette.cyan, 300),
                ),
                Positioned(
                  bottom: -160 + 50 * (1 - _c.value),
                  left: -100 + 80 * _c.value,
                  child: _orb(Palette.lime, 300),
                ),
              ],
            ),
          ),
          widget.child,
        ],
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? borderColor;
  final Color? tint;
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.borderColor,
    this.tint,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          width: double.infinity,
          padding: padding,
          decoration: BoxDecoration(
            color: tint ?? Palette.glass,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: borderColor ?? Palette.glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }
}

class GlowButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final Gradient gradient;
  final Color glow;

  const GlowButton({
    super.key,
    required this.label,
    required this.icon,
    this.onTap,
    this.gradient = auroraGradient,
    this.glow = Palette.violet,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onTap == null ? 0.4 : 1,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: glow.withOpacity(0.45), blurRadius: 22)],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RingPainter extends CustomPainter {
  final double value;
  final Color color;
  final double thickness;
  RingPainter(this.value, this.color, {this.thickness = 12});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final radius = math.min(size.width, size.height) / 2 - thickness;
    final rect = Rect.fromCircle(center: c, radius: radius);
    final v = value.clamp(0.0, 1.0).toDouble();
    canvas.drawCircle(
      c,
      radius,
      Paint()
        ..color = const Color(0x1AFFFFFF)
        ..style = PaintingStyle.stroke
        ..strokeWidth = thickness,
    );
    canvas.drawArc(
      rect,
      -math.pi / 2,
      2 * math.pi * v,
      false,
      Paint()
        ..color = color.withOpacity(0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = thickness + 6
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawArc(
      rect,
      -math.pi / 2,
      2 * math.pi * v,
      false,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = thickness
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant RingPainter old) =>
      old.value != value || old.color != color;
}
