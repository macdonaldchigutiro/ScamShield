import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'sim.dart';
import 'theme.dart';

Color statusColor(Status s) {
  switch (s) {
    case Status.present:
      return Palette.lime;
    case Status.late:
      return Palette.amber;
    case Status.absent:
      return Palette.red;
    case Status.excused:
      return Palette.cyan;
    case Status.pending:
      return Palette.dim;
  }
}

String statusLabel(Status s) {
  switch (s) {
    case Status.present:
      return 'PRESENT';
    case Status.late:
      return 'LATE';
    case Status.absent:
      return 'ABSENT';
    case Status.excused:
      return 'EXCUSED';
    case Status.pending:
      return 'NOT YET';
  }
}

IconData methodIcon(Method m) {
  switch (m) {
    case Method.rfid:
      return Icons.contactless_outlined;
    case Method.face:
      return Icons.face_retouching_natural;
    case Method.qr:
      return Icons.qr_code_2;
    case Method.manual:
      return Icons.edit_outlined;
  }
}

String methodLabel(Method m) {
  switch (m) {
    case Method.rfid:
      return 'Card';
    case Method.face:
      return 'Face';
    case Method.qr:
      return 'QR';
    case Method.manual:
      return 'Teacher';
  }
}

class PulseScreen extends StatelessWidget {
  final SchoolSim sim;
  const PulseScreen({super.key, required this.sim});

  Widget _count(String label, int value, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text('$value',
              style: TextStyle(
                  color: color, fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(
                  color: Palette.dim, fontSize: 9, letterSpacing: 1.5)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pct = sim.herePct;
    final ringColor = pct >= 0.9
        ? Palette.lime
        : (pct >= 0.75 ? Palette.amber : (sim.cutoffDone ? Palette.red : Palette.cyan));

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
      children: [
        GlassCard(
          child: Column(
            children: [
              Row(
                children: [
                  SizedBox(
                    width: 150,
                    height: 150,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        TweenAnimationBuilder<double>(
                          tween: Tween<double>(begin: 0, end: pct),
                          duration: const Duration(milliseconds: 500),
                          builder: (context, v, _) => CustomPaint(
                            size: const Size(150, 150),
                            painter: RingPainter(v, ringColor, thickness: 13),
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('${(pct * 100).round()}%',
                                style: TextStyle(
                                    color: ringColor,
                                    fontSize: 36,
                                    fontWeight: FontWeight.w800)),
                            const Text('IN SCHOOL',
                                style: TextStyle(
                                    color: Palette.dim,
                                    fontSize: 10,
                                    letterSpacing: 2)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${sim.here} of ${sim.total}',
                            style: const TextStyle(
                                color: Palette.text,
                                fontSize: 20,
                                fontWeight: FontWeight.w800)),
                        const Text('students have arrived',
                            style: TextStyle(color: Palette.dim, fontSize: 12)),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: ringColor.withOpacity(0.14),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: ringColor.withOpacity(0.6)),
                          ),
                          child: Text(sim.phase.toUpperCase(),
                              style: TextStyle(
                                  color: ringColor,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.5)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _count('ON TIME', sim.presentCount, Palette.lime),
                  _count('LATE', sim.lateCount, Palette.amber),
                  _count('ABSENT', sim.absentCount, Palette.red),
                  _count('NOT YET', sim.pendingCount, Palette.dim),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const Text('ARRIVALS EVERY 5 MINUTES',
            style: TextStyle(color: Palette.cyan, letterSpacing: 2, fontSize: 11)),
        const SizedBox(height: 8),
        GlassCard(
          child: SizedBox(
            height: 150,
            width: double.infinity,
            child: CustomPaint(painter: ArrivalsPainter(sim)),
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: GlassCard(
                child: Row(
                  children: [
                    const Icon(Icons.sms_outlined, color: Palette.cyan),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${sim.guardiansNotified}',
                              style: const TextStyle(
                                  color: Palette.cyan,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800)),
                          const Text('PARENTS TEXTED',
                              style: TextStyle(
                                  color: Palette.dim,
                                  fontSize: 9,
                                  letterSpacing: 1.5)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: GlassCard(
                child: Row(
                  children: [
                    const Icon(Icons.crisis_alert, color: Palette.amber),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${sim.cutoffDone ? sim.atRisk.length : 0}',
                              style: const TextStyle(
                                  color: Palette.amber,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800)),
                          const Text('AT-RISK STUDENTS',
                              style: TextStyle(
                                  color: Palette.dim,
                                  fontSize: 9,
                                  letterSpacing: 1.5)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Palette.lime,
                boxShadow: [BoxShadow(color: Palette.lime, blurRadius: 8)],
              ),
            ),
            const SizedBox(width: 8),
            const Text('LIVE CHECK-INS',
                style: TextStyle(
                    color: Palette.cyan, letterSpacing: 2, fontSize: 11)),
          ],
        ),
        const SizedBox(height: 8),
        if (sim.events.isEmpty)
          const GlassCard(
            child: Text('Waiting for the first student to arrive…',
                style: TextStyle(color: Palette.dim)),
          ),
        for (final e in sim.events.take(6))
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: statusColor(e.status).withOpacity(0.15),
                      border: Border.all(color: statusColor(e.status)),
                    ),
                    child: Text(e.student.name[0],
                        style: TextStyle(
                            color: statusColor(e.status),
                            fontWeight: FontWeight.w800)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(e.student.name,
                            style: const TextStyle(
                                color: Palette.text, fontWeight: FontWeight.w700)),
                        Row(
                          children: [
                            Icon(methodIcon(e.method),
                                size: 13, color: Palette.dim),
                            const SizedBox(width: 4),
                            Flexible(
                              child: Text(
                                '${e.student.classId} • ${e.gate} • ${methodLabel(e.method)}',
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: Palette.dim, fontSize: 11),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(fmt(e.minute),
                          style: const TextStyle(
                              color: Palette.text, fontSize: 13)),
                      Text(statusLabel(e.status),
                          style: TextStyle(
                              color: statusColor(e.status),
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1)),
                    ],
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class ArrivalsPainter extends CustomPainter {
  final SchoolSim s;
  ArrivalsPainter(this.s) : super(repaint: s);

  @override
  void paint(Canvas canvas, Size size) {
    const l = 6.0, r = 6.0, tp = 14.0, b = 20.0;
    final plot = Rect.fromLTRB(l, tp, size.width - r, size.height - b);
    final n = s.buckets.length;
    final slot = plot.width / n;
    final maxV = math.max(8, s.buckets.reduce(math.max)).toDouble() * 1.2;
    final nowBucket = ((s.minutes - SchoolSim.dayStart) / 5).floor();
    final bellBucket = ((SchoolSim.bell - SchoolSim.dayStart) / 5).floor();

    canvas.drawLine(
      Offset(plot.left, plot.bottom),
      Offset(plot.right, plot.bottom),
      Paint()
        ..color = const Color(0x22FFFFFF)
        ..strokeWidth = 1,
    );

    for (int i = 0; i < n; i++) {
      final v = s.buckets[i];
      if (v == 0) continue;
      final bh = plot.height * v / maxV;
      final color = i < bellBucket ? Palette.lime : Palette.amber;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(plot.left + slot * i + 1.5, plot.bottom - bh, slot - 3, bh),
        const Radius.circular(3),
      );
      if (i == nowBucket) {
        canvas.drawRRect(
          rect,
          Paint()
            ..color = color.withOpacity(0.6)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
        );
      }
      canvas.drawRRect(
          rect, Paint()..color = i == nowBucket ? color : color.withOpacity(0.7));
    }

    final bx = plot.left + slot * (bellBucket + 1);
    for (double y = plot.top; y < plot.bottom; y += 8) {
      canvas.drawLine(
        Offset(bx, y),
        Offset(bx, math.min(y + 4, plot.bottom)),
        Paint()
          ..color = Palette.red.withOpacity(0.8)
          ..strokeWidth = 1.5,
      );
    }
    drawText(canvas, 'BELL ${fmt(SchoolSim.bell)}', Offset(bx - 2, plot.top - 6), 9,
        Palette.red, letterSpacing: 1);

    for (final m in [390.0, 420.0, 480.0, 540.0]) {
      final x = plot.left + slot * ((m - SchoolSim.dayStart) / 5);
      drawText(canvas, fmt(m), Offset(x + 10, plot.bottom + 11), 9, Palette.dim);
    }
  }

  @override
  bool shouldRepaint(covariant ArrivalsPainter old) => false;
}
