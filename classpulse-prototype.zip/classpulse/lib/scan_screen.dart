import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'pulse_screen.dart';
import 'sim.dart';
import 'theme.dart';

class ScanScreen extends StatefulWidget {
  final SchoolSim sim;
  const ScanScreen({super.key, required this.sim});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2200),
  )..repeat();

  Method _method = Method.rfid;
  bool _scanning = false;
  TapResult? _result;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    HapticFeedback.lightImpact();
    setState(() {
      _scanning = true;
      _result = null;
    });
    await Future.delayed(const Duration(milliseconds: 1500));
    if (!mounted) return;
    final r = widget.sim.simulateTap(_method);
    if (r.ok) {
      HapticFeedback.mediumImpact();
    } else {
      HapticFeedback.heavyImpact();
    }
    setState(() {
      _scanning = false;
      _result = r;
    });
  }

  Widget _seg(Method m, String label, IconData icon) {
    final sel = _method == m;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() {
          _method = m;
          _result = null;
        }),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: sel ? auroraGradient : null,
            borderRadius: BorderRadius.circular(14),
            boxShadow: sel
                ? [BoxShadow(color: Palette.violet.withOpacity(0.4), blurRadius: 16)]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: sel ? Colors.white : Palette.dim),
              const SizedBox(width: 6),
              Text(label,
                  style: TextStyle(
                      color: sel ? Colors.white : Palette.dim,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.5,
                      fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final sim = widget.sim;
    final r = _result;
    final faceOff = _method == Method.face && !sim.faceEnabled;
    final hint = _method == Method.rfid
        ? 'Student taps their card on the reader.'
        : (_method == Method.face
            ? 'Only students with guardian consent can use face check-in. No photo is saved.'
            : 'Student shows the QR code on their card or phone.');

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        const Text('SCAN STATION',
            style: TextStyle(color: Palette.cyan, letterSpacing: 2, fontSize: 12)),
        const SizedBox(height: 4),
        const Text('Try the check-in a student would use at the gate or classroom door.',
            style: TextStyle(color: Palette.dim, fontSize: 12)),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: Palette.glass,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Palette.glassBorder),
          ),
          child: Row(
            children: [
              _seg(Method.rfid, 'CARD', Icons.contactless_outlined),
              _seg(Method.face, 'FACE', Icons.face_retouching_natural),
              _seg(Method.qr, 'QR', Icons.qr_code_2),
            ],
          ),
        ),
        const SizedBox(height: 14),
        GlassCard(
          padding: const EdgeInsets.all(8),
          child: SizedBox(
            height: 250,
            width: double.infinity,
            child: AnimatedBuilder(
              animation: _c,
              builder: (context, _) => CustomPaint(
                painter: _ScannerPainter(
                    _method, _c.value, _scanning, r != null && r.ok, faceOff),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(hint,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Palette.dim, fontSize: 12, height: 1.35)),
        const SizedBox(height: 14),
        GlowButton(
          label: _scanning ? 'SCANNING…' : 'SIMULATE A CHECK-IN',
          icon: Icons.sensors,
          onTap: _scanning ? null : _run,
        ),
        const SizedBox(height: 16),
        if (r != null)
          GlassCard(
            borderColor: (r.ok
                    ? (r.student!.status == Status.late ? Palette.amber : Palette.lime)
                    : (r.duplicate ? Palette.amber : Palette.red))
                .withOpacity(0.6),
            child: r.student == null
                ? Row(
                    children: [
                      const Icon(Icons.info_outline, color: Palette.red),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(r.message,
                            style: const TextStyle(
                                color: Palette.text, height: 1.4)),
                      ),
                    ],
                  )
                : Row(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Palette.violet.withOpacity(0.2),
                          border: Border.all(color: Palette.violet, width: 2),
                        ),
                        child: Text(r.student!.name[0],
                            style: const TextStyle(
                                color: Palette.text,
                                fontSize: 24,
                                fontWeight: FontWeight.w800)),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(r.student!.name,
                                style: const TextStyle(
                                    color: Palette.text,
                                    fontSize: 17,
                                    fontWeight: FontWeight.w800)),
                            Text(r.student!.classId,
                                style: const TextStyle(
                                    color: Palette.dim, fontSize: 12)),
                            const SizedBox(height: 4),
                            Text(
                              r.message,
                              style: TextStyle(
                                  color: r.ok
                                      ? (r.student!.status == Status.late
                                          ? Palette.amber
                                          : Palette.lime)
                                      : Palette.amber,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13),
                            ),
                            if (_method == Method.face && r.ok)
                              const Text('Liveness check passed • no photo saved',
                                  style: TextStyle(
                                      color: Palette.dim, fontSize: 11)),
                          ],
                        ),
                      ),
                      Icon(
                        r.ok ? Icons.check_circle : Icons.info,
                        color: r.ok ? Palette.lime : Palette.amber,
                        size: 30,
                      ),
                    ],
                  ),
          ),
      ],
    );
  }
}

class _ScannerPainter extends CustomPainter {
  final Method method;
  final double t;
  final bool scanning, success, off;
  _ScannerPainter(this.method, this.t, this.scanning, this.success, this.off);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final base = off ? Palette.red : (success ? Palette.lime : Palette.cyan);

    // Corner brackets
    final br = Paint()
      ..color = base
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    const m = 14.0, l = 30.0;
    final w = size.width, h = size.height;
    final path = Path()
      ..moveTo(m, m + l)..lineTo(m, m)..lineTo(m + l, m)
      ..moveTo(w - m - l, m)..lineTo(w - m, m)..lineTo(w - m, m + l)
      ..moveTo(m, h - m - l)..lineTo(m, h - m)..lineTo(m + l, h - m)
      ..moveTo(w - m - l, h - m)..lineTo(w - m, h - m)..lineTo(w - m, h - m - l);
    canvas.drawPath(
      path,
      Paint()
        ..color = base.withOpacity(0.4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 9
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    canvas.drawPath(path, br);

    if (method == Method.rfid) {
      // Contactless waves
      for (int k = 0; k < 3; k++) {
        final ph = (t * (scanning ? 2 : 1) + k / 3) % 1.0;
        canvas.drawCircle(
          c,
          30 + 80 * ph,
          Paint()
            ..color = base.withOpacity((1 - ph) * 0.8)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2.5,
        );
      }
      final card = RRect.fromRectAndRadius(
        Rect.fromCenter(center: c, width: 84, height: 54),
        const Radius.circular(10),
      );
      canvas.drawRRect(
        card,
        Paint()
          ..color = base.withOpacity(0.5)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
      );
      canvas.drawRRect(card, Paint()..color = const Color(0xFF16124A));
      canvas.drawRRect(
        card,
        Paint()
          ..color = base
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
      canvas.drawRect(
        Rect.fromCenter(center: c + const Offset(-22, -8), width: 18, height: 14),
        Paint()..color = Palette.amber.withOpacity(0.8),
      );
      drawText(canvas, 'STUDENT', c + const Offset(14, 14), 9, Palette.dim,
          letterSpacing: 2);
    } else if (method == Method.face) {
      final oval = Rect.fromCenter(center: c, width: 120, height: 160);
      canvas.drawOval(
        oval,
        Paint()
          ..color = base.withOpacity(0.35)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 8
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
      for (double a = 0; a < 2 * math.pi; a += 0.35) {
        final p = Offset(
          c.dx + math.cos(a + t * 2) * 60,
          c.dy + math.sin(a + t * 2) * 80,
        );
        canvas.drawCircle(p, 2.2, Paint()..color = base);
      }
      // Landmark dots
      final dots = [
        const Offset(-22, -20), const Offset(22, -20), const Offset(0, 0),
        const Offset(-16, 28), const Offset(16, 28), const Offset(0, 34),
      ];
      for (final d in dots) {
        canvas.drawCircle(c + d, 2.5,
            Paint()..color = base.withOpacity(scanning || success ? 0.9 : 0.25));
      }
      final y = c.dy - 80 + 160 * (0.5 + 0.5 * math.sin(t * 2 * math.pi));
      canvas.drawLine(
        Offset(c.dx - 66, y),
        Offset(c.dx + 66, y),
        Paint()
          ..color = base
          ..strokeWidth = 2.5,
      );
      if (off) {
        drawText(canvas, 'FACE CHECK-IN IS OFF', Offset(c.dx, size.height - 28), 11,
            Palette.red, letterSpacing: 2);
      }
    } else {
      final box = Rect.fromCenter(center: c, width: 120, height: 120);
      final r = math.Random(3);
      for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
          if (r.nextDouble() > 0.5) {
            canvas.drawRect(
              Rect.fromLTWH(box.left + i * 12, box.top + j * 12, 10, 10),
              Paint()..color = base.withOpacity(0.55),
            );
          }
        }
      }
      for (final o in [
        box.topLeft, box.topRight - const Offset(30, 0), box.bottomLeft - const Offset(0, 30)
      ]) {
        canvas.drawRect(Rect.fromLTWH(o.dx, o.dy, 30, 30),
            Paint()..color = const Color(0xFF16124A));
        canvas.drawRect(
          Rect.fromLTWH(o.dx, o.dy, 30, 30),
          Paint()
            ..color = base
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3,
        );
      }
      final y = box.top + box.height * (0.5 + 0.5 * math.sin(t * 2 * math.pi));
      canvas.drawLine(
        Offset(box.left - 10, y),
        Offset(box.right + 10, y),
        Paint()
          ..color = base
          ..strokeWidth = 2.5,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ScannerPainter old) => true;
}
