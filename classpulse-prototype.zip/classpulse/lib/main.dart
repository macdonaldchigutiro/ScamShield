import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'classes_screen.dart';
import 'insights_screen.dart';
import 'pulse_screen.dart';
import 'scan_screen.dart';
import 'sim.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Palette.bg,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const ClassPulseApp());
}

class ClassPulseApp extends StatelessWidget {
  const ClassPulseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ClassPulse',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Palette.bg,
        colorScheme: const ColorScheme.dark(
          primary: Palette.violet,
          secondary: Palette.cyan,
        ),
        useMaterial3: true,
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final SchoolSim _sim = SchoolSim();
  int _tab = 0;
  final Set<String> _seen = {};

  @override
  void initState() {
    super.initState();
    _sim.addListener(_onSim);
  }

  @override
  void dispose() {
    _sim.removeListener(_onSim);
    _sim.dispose();
    super.dispose();
  }

  void _onSim() {
    final now = _sim.alerts;
    final ids = now.map((a) => a.id).toSet();
    for (final a in now) {
      if (_seen.add(a.id) && a.severity == 'warning') _notify(a);
    }
    _seen.retainAll(ids);
  }

  void _notify(SchoolAlert a) {
    if (!mounted) return;
    HapticFeedback.mediumImpact();
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF5A3A08),
        content: Text(a.title),
        action: SnackBarAction(
          label: 'VIEW',
          textColor: Colors.white,
          onPressed: () => setState(() => _tab = 3),
        ),
      ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AuroraBackground(
        child: SafeArea(
          child: Column(
            children: [
              _header(),
              Expanded(
                child: AnimatedBuilder(
                  animation: _sim,
                  builder: (context, _) => IndexedStack(
                    index: _tab,
                    children: [
                      PulseScreen(sim: _sim),
                      ClassesScreen(sim: _sim),
                      ScanScreen(sim: _sim),
                      InsightsScreen(sim: _sim),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: AnimatedBuilder(
        animation: _sim,
        builder: (context, _) {
          final n = _sim.alerts.where((a) => a.severity != 'info').length;
          return NavigationBar(
            backgroundColor: const Color(0xFF0A0820),
            indicatorColor: Palette.violet.withOpacity(0.25),
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              const NavigationDestination(
                  icon: Icon(Icons.monitor_heart_outlined), label: 'Pulse'),
              const NavigationDestination(
                  icon: Icon(Icons.grid_view_rounded), label: 'Classes'),
              const NavigationDestination(
                  icon: Icon(Icons.sensors), label: 'Scan'),
              NavigationDestination(
                icon: Badge(
                  isLabelVisible: n > 0,
                  label: Text('$n'),
                  child: const Icon(Icons.insights),
                ),
                label: 'Insights',
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 4, 4),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (r) => auroraGradient.createShader(r),
                  child: const Text('CLASSPULSE',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 5,
                        color: Colors.white,
                      )),
                ),
                AnimatedBuilder(
                  animation: _sim,
                  builder: (context, _) => Text(
                    'GREENFIELD HIGH (DEMO)  •  ${fmt(_sim.minutes)}',
                    style: const TextStyle(
                        color: Palette.dim, fontSize: 10, letterSpacing: 2),
                  ),
                ),
              ],
            ),
          ),
          AnimatedBuilder(
            animation: _sim,
            builder: (context, _) => IconButton(
              tooltip: _sim.running ? 'Pause' : 'Play',
              onPressed: _sim.togglePlay,
              icon: Icon(
                _sim.running ? Icons.pause_circle_outline : Icons.play_circle_outline,
                color: Palette.cyan,
              ),
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.science_outlined, color: Palette.lime),
            tooltip: 'Demo controls',
            color: const Color(0xFF1A1545),
            onSelected: (v) {
              switch (v) {
                case 'cutoff':
                  _sim.skipToCutoff();
                  break;
                case 'dup':
                  _sim.injectDuplicate();
                  break;
                case 'unknown':
                  _sim.injectUnknown();
                  break;
                default:
                  _seen.clear();
                  _sim.reset();
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'cutoff', child: Text('Skip to 08:30 (register closes)')),
              PopupMenuItem(value: 'dup', child: Text('Shared card alert')),
              PopupMenuItem(value: 'unknown', child: Text('Unknown card alert')),
              PopupMenuItem(value: 'reset', child: Text('Restart the school day')),
            ],
          ),
        ],
      ),
    );
  }
}
